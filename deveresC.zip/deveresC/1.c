/******************************************************************************

1) Escrever um algoritmo em C para exibir os m�ltiplos de 3 
compreendidos no intervalo: [3 100].

*******************************************************************************/
#include <stdio.h>

int main(void)
{
	int i;
    for (i = 3; i <= 100; i += 3)
    {
        printf("%d\n", i);
    }

    return 0;
}


