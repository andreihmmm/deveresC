/******************************************************************************

9) Escrever um algoritmo que leia v�rios N�meros N (um por vez) que, no intervalo entre [10 90],
divididos por 5 possuem resto 2. Exiba a soma dos n�meros lidos, parando o programa para N = 0.

*******************************************************************************/
#include <stdio.h>
#include <locale.h>

int main(void)
{
    int N,soma = 0;
    printf("numeros que no intervalo entre [10 90], divididos por 5 possuem resto 2\n");
    do
    {
    	setlocale(LC_ALL,"");
        printf("Insira um valor: ");
        scanf("%d", &N);
        if (N >= 10 && N <= 90 && N % 5 == 2)
        {
            printf("%d\n", N);
            soma += N;
        }
        else if (N != 0)
        {
            printf("N�mero n�o adicionado.\n");
        }
        else
            printf("programa finalizado\n");
    }
    while (N != 0);
    printf("SOMA dos numeros: %d", soma);

    return 0;
}



