/******************************************************************************

7) Escrever um algoritmo que conte e soma todos os n�meros �mpares que s�o m�ltiplos de tr�s e N�O
m�ltiplos de 5 que se encontram no intervalo [9 90]. Exiba a Contagem e a Soma destes n�meros.

*******************************************************************************/
#include <stdio.h>

int main(void)
{
    int soma, contador;
    contador = 0;
    soma = 0;
    int i;
    for (i = 9; i <= 90; i += 2)
    {
        if (i % 3 == 0 && i % 5 != 0)
        {
            soma += i;
            contador++;
            printf("%3d", i);
        }
    }
    printf("\nSOMA: %d\nQUANTIDADE DE NUMEROS: %d", soma, contador);

    return 0;
}


