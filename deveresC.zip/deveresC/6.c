/******************************************************************************

6) Escreva um algoritmo em C que leia o sal�rio em reais (R$) de 1000 clientes de um shopping e exiba na
tela, em porcentagem, a divis�o dos clientes por tipo: A, B ou C, conforme a seguir:
? A: Maior ou igual a 15 Sal�rios M�nimos ou
? B: Menor que 15 Sal�rios M�nimos ou maior ou igual a 5 Sal�rios M�nimos ou
? C: Menor que 5 Sal�rios M�nimos.
Declarar o Sal�rio M�nimo (SM: R$ 880.05) como constante com o comando: #define.

*******************************************************************************/
#include <stdio.h>
#define SM 880.05
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");
    float salarioAtual;
    int quantidadeClientes, a, b, c;
    a = 0;
	b = 0;
	c = 0;
    quantidadeClientes = 5;
    int i;
    for (i = 0; i < quantidadeClientes; i++)
    {
        printf("Digite seu sal�rio imediatamente: R$");
        scanf("%f", &salarioAtual);
        if (salarioAtual <= 5 * SM)
        {
            c++;
    	}
        else if (salarioAtual <= 15 * SM)
        {
            b++;
		}
        else
        {
            a++;
    	}
    }
    printf("CLIENTES CLASSE A: %d%%\nCLIENTES CLASSE B: %d%%\nCLIENTES CLASSE C: %d%%\n", 
    a*100/quantidadeClientes, b*100/quantidadeClientes, c*100/quantidadeClientes);

    return 0;
}


