/******************************************************************************

5) Escreva um algoritmo em C que leia de 10.000 habitantes de uma pequena cidade se est� empregado ou
n�o e exiba em porcentagem a quantidade de empregados e desempregados desta pequena cidade.

*******************************************************************************/
#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");
	int i;
	int empregados = 0; 
    int habitantes, situacao;
    habitantes = 10000;
    for (i = 0; i < habitantes; i++)
    {
        printf("\tDigite sua situa��o:\nEMPREGADO (1)\nDESEMPREGADO (0)\n");
        scanf("%d", &situacao);
        empregados += situacao;
    }
    printf("QUANTIDADE DE EMPREGADOS: %.1f%%\nQUANTIDADE DE DESEMPREGADOS: %.1f%%\n", empregados*100.0/habitantes, 100-(empregados*100.0/habitantes));

    return 0;
}


