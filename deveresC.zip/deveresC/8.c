/******************************************************************************

8) Um marca de sucos que saber a opini�o dos seus clientes sobre tr�s diferentes novos �mix� de sabores.
As degusta��es e vota��o se realizaram num supermercado durante certo per�odo. Fa�a um algoritmo em
C, que exiba a porcentagem dos clientes que gostaram da op��o: 1: Mix 1, 2: Mix 2 ou 3: Mix 3 de
sabores. Pare o algoritmo quando for digitada a op��o zero (0).

*******************************************************************************/
#include <stdio.h>

int main(void)
{
    int votoAtual = 0, m1 = 0, m2 = 0, m3 = 0, totalClientes = 0;
    int i = 0;
    printf("\tQUESTION�RIO\n");
    do
    {
        printf("\n\tDigite seu mix favorito:\nMIX 1 (Digite 1)\nMIX 2 (Digite 2)\nMIX 3 (Digite 3)\n");
        scanf("%d", &votoAtual);
        if (votoAtual == 1)
        {
            m1++;
        }
        else if (votoAtual == 2)
        {
            m2++;
        }
        else if (votoAtual == 3)
        {
            m3++;
        }
        else if (votoAtual != 0)
        {
            printf("Digite um numero valido");
            i--;
            totalClientes--;
        }
        else
        {
            printf("programa finalizado\n");
            break;
        }
        i++;
        totalClientes++;
    }
    while (votoAtual != 0);
    printf("\n\tRESULTADOS:\nVotos MIX 1: %.2f%%\nVotos MIX 2: %.2f%%\nVotos MIX 3: %.2f%%",
    m1*100.0/totalClientes, m2*100.0/totalClientes, m3*100.0/totalClientes);
    return 0;
}


