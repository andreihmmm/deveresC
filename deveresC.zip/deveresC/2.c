/******************************************************************************

2) Escrever um algoritmo em C para exibir os m�ltiplos de 11 e a soma dos m�ltiplos de 11, 
em ordem decrescente (inversa), compreendidos entre o intervalo: [300 400].

*******************************************************************************/
#include <stdio.h>

int main(void)
{
    int soma, i;
    for (i = 300; i <= 400; i++)
    {
        if (i % 11 == 0)
        {
            printf("%4d", i);
            soma += i;
        }
    }
    printf("\nSoma: %d", soma);
    return 0;
}


