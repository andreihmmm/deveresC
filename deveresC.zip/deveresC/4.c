/******************************************************************************

4) Fa�a um algoritmo que exiba a soma dos PARES e �MPARES compreendidos entre [999 100].

*******************************************************************************/
#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");
    int Psoma, Isoma, i;
    printf("soma dos PARES e �MPARES compreendidos entre [999 100]");
    for (i = 999; i >= 100; i--)
    {
        if (i % 2 == 0)
        {
            Psoma += i;
        }
        else
        {
            Isoma += i;
        }
    }
    printf("\nSOMA DOS PARES: %d\nSOMA DOS �MPARES: %d", Psoma, Isoma);

    return 0;
}



