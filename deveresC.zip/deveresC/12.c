/******************************************************************************

12) Os comerciantes das Praias de Vila-Velha querem saber a temperatura m�dia do ver�o capixaba. Escreva
um algoritmo em C que leia a temperatura di�ria no ver�o e exiba a temperatura m�dia da esta��o
parando o algoritmo quando for digitada uma temperatura fora da esta��o. Sabe-se que as temperaturas,
na esta��o de ver�o Capixaba, ficam acima de 28 �C.

*******************************************************************************/
#include <stdio.h>

int main(void)
{
    int tempAtual, tempSoma = 0, contador = 0;
    do
    {
        printf("Insira a temperatura: ");
        scanf("%d", &tempAtual);
        if (tempAtual > 28)
        {
            tempSoma += tempAtual;
            contador++;
        }
    }
    while (tempAtual > 28);
    printf("Temperatura media: %.2f", tempSoma * 1.0 / contador);

    return 0;
}


