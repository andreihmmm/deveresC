/******************************************************************************

13) Escrever um algoritmo em C, para cada item a seguir, que leia a altura em metros e o sexo (M: para
Masculino ou F: para Feminino) de 50 pessoas. Este algoritmo dever� mostrar na tela:
a) A altura da pessoa mais alta por sexo.
b) M�dia da altura dos homens e das mulheres.
c) Quantidade de Homens e Mulheres, em porcentagem, com mais de 1.82 metros de altura.

*******************************************************************************/
#include <stdio.h>


int main(void)
{
    char sexoAtual;
    int Mtotal = 0, Ftotal = 0, totalPessoas, Mgrandes = 0, Fgrandes = 0;
    float alturaAtual, MalturaTotal = 0, FalturaTotal = 0, Mmaior, Fmaior;
    totalPessoas = 5;
    int i;
    for (i = 1; i <= totalPessoas; i++)
    {
        printf("\nDigite sua altura em metros: ");
        scanf("%f", &alturaAtual);
        printf("\nDigite seu sexo (M: para Masculino ou F: para Feminino): ");
        scanf(" %c", &sexoAtual);
        if (sexoAtual == 'M')
        {
            Mtotal++;
            MalturaTotal += alturaAtual;
            if (alturaAtual > Mmaior)
            {
                Mmaior = alturaAtual;
            }
            if (alturaAtual > 1.82)
            {
                Mgrandes++;
            }
        }
        else if (sexoAtual == 'F')
        {
            Ftotal++;
            FalturaTotal += alturaAtual;
            if (alturaAtual > Fmaior)
            {
                Fmaior = alturaAtual;
            }
            if (alturaAtual > 1.82)
            {
                Fgrandes++;
            }
        }
        else
        {
            printf("Insira um sexo valido\n");
            i--;
        }
    }
    printf("\na) A altura da pessoa mais alta por sexo.");
    printf("\nMAIOR HOMEM: %.2f\nMAIOR MULHER: %.2f\n", Mmaior, Fmaior);
    printf("\nb) Media da altura dos homens e das mulheres.");
    printf("\nM�DIA HOMENS: %.2f\nM�DIA MULHERES: %.2f\n", MalturaTotal / Mtotal, FalturaTotal / Ftotal);
    printf("\nc) Quantidade de Homens e Mulheres, em porcentagem, com mais de 1.82 metros de altura.");
    printf("\nHOMENS : %d%%\nMULHERES: %d%%", Mgrandes * 100 / Mtotal, Fgrandes*100/Ftotal);
    return 0;
}




