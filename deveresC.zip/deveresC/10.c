/******************************************************************************

10) Escrever um algoritmo em C para que calcule a m�dia dos n�meros m�ltiplos de 6 que se encontram no
intervalo de [6, 6x]. Onde x � um (1) �nico n�mero inteiro positivo (x = 1), lido do usu�rio.

*******************************************************************************/
#include <stdio.h>

int main(void)
{
    int x, soma, quantidadeSeis;
    soma = 0;
    quantidadeSeis = 0;
    printf("Digite um numero inteiro positivo.\n");
    scanf("%d", &x);
    if (x < 1)
    {
        printf("adeus");
        return 0;
    }
    
    printf("\tNUMEROS\n");

	int i;
    for (i = 6; i <= 6 * x; i++)
    {
        if (i % 6 == 0)
        {
            printf("%d\n", i);
            soma += i;
            quantidadeSeis++;
        }
    }
    printf("MEDIA: %d", soma / quantidadeSeis);
    return 0;
}


