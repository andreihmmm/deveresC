/******************************************************************************

11) Escrever um algoritmo em C em que o usu�rio entre com um n�mero inteiro qualquer {? ? Z} e exiba na
tela os 20 n�meros subseq�entes ao que foi digitado pelo usu�rio.

*******************************************************************************/
#include <stdio.h>

int main(void)
{
    int n;
    printf("Digite um numero n: ");
    scanf("%d", &n);
    int i;
    for (i = n + 1; i <= n + 20; i++)
    {
        printf("%5d", i);
    }

    return 0;
}


