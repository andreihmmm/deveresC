/******************************************************************************

3) Escrever um algoritmo em C para exibir os m�ltiplos de ? compreendidos entre o intervalo:
[LimiteInferior LimiteSuperior] e N. Sendo que:
? {? ? N/ ? = 2}
? {LimiteInferior , LimiteSuperior ? N/ LimiteSuperior = LimiteInferior}

*******************************************************************************/
#include <stdio.h>
#include <locale.h>

int main(void)
{
	setlocale(LC_ALL,"");
    int n, LimiteInferior , LimiteSuperior;
    n = 0;
    
    do
    {
    printf("Insira o n�mero cujos m�ltiplos ser�o exibidos (maior ou igual a 2): ");
    scanf("%d", &n);
    }
    while (n <= 2);
    
    LimiteSuperior = 0;
    LimiteInferior = 1;
    
    do
    {        
        printf("Insira o limite inferior: ");
        scanf("%d", &LimiteInferior);
        printf("Insira o limite superior: ");
        scanf("%d", &LimiteSuperior);

    }
    while (LimiteSuperior < LimiteInferior);
    
    int i;
    for (i = LimiteInferior; i <= LimiteSuperior; i++)
    {
        if (i % n == 0)
        {
           printf("%5d\n", i); 
        }
    }
    
    return 0;
}



